### **Product Requirements Document (PRD): Account Settings - General Tab

#### **1. Introduction**
The **Account Settings** page in Shothik AI allows users to manage their personal information, including profile details and contact information. This PRD focuses on the **General** tab within the Account Settings, where users can update their name, email address, address, country, city, and postal code. The design ensures a clean, intuitive, and responsive experience for users across devices.

#### **2. Objectives**
- Provide users with an easy way to update their personal information.
- Ensure data security by validating inputs and confirming changes.
- Maintain consistency with the platform's overall design and user experience.
- Support responsiveness for both desktop and mobile devices.

#### **3. User Stories**
1. **As a user:**
   - I want to update my profile picture and personal details easily.
   - I expect clear validation messages if I make errors while updating my information.
   - I need a confirmation button to save changes after editing.

2. **As an authenticated user:**
   - I want to see my current information pre-filled in the fields.
   - I expect certain fields (e.g., email) to be read-only or have specific restrictions.

3. **As a mobile user:**
   - I want the form to adapt seamlessly to my screen size.
   - I need quick access to all fields without excessive scrolling.

---

#### **4. Functional Requirements**

##### **4.1 Navigation**
- **Tabs:**
  - The Account Settings page includes two tabs:
    - **General:** For managing personal information (name, email, address, etc.).
    - **Billing:** For managing payment-related details (not covered in this PRD).
  - The **General** tab is highlighted when selected.

##### **4.2 Profile Picture Upload**
- **Component:**
  - A circular placeholder for the profile picture.
  - An "Upload Photo" button with an icon (`📷`) for uploading images.
  - Supported file types: `.jpeg`, `.jpg`, `.png`, `.gif`.
  - Validation:
    - Display an error message if the file type is unsupported.
    - Show a loading indicator during upload.
    - Confirm successful upload with a visual update of the profile picture.

##### **4.3 Personal Information Fields**
- **Fields:**
  - **Name:**  
    - Input field for the user's full name.
    - Required field.
    - Validation: Allow only alphanumeric characters, spaces, and basic punctuation.
  - **Email Address:**  
    - Readonly field displaying the user's verified email address.
    - Includes a green badge labeled "Verified."
    - Tooltip: "Email cannot be changed after sign-up."
  - **Address:**  
    - Text area for entering the user's physical address.
    - Optional field.
  - **Country:**  
    - Dropdown menu listing countries.
    - Pre-selected based on the user's current location or default setting.
    - Required field.
  - **City:**  
    - Input field for the user's city.
    - Optional field.
  - **Postal Code:**  
    - Input field for the user's postal/zip code.
    - Optional field.
    - Validation: Numeric input only.

##### **4.4 Save Changes Button**
- **Behavior:**
  - Users can click the "Save Changes" button to submit updates.
  - Upon clicking, validate all required fields.
  - If validation passes, display a success message (e.g., "Changes saved successfully").
  - If validation fails, highlight invalid fields and display error messages.

##### **4.5 Responsive Design**
- **Desktop:**
  - Two-column layout:
    - Left column: Profile picture upload section.
    - Right column: Personal information form.
- **Mobile:**
  - Stacked layout with fields displayed vertically.
  - Profile picture upload section at the top.
  - Form fields below, with labels aligned above input fields.

---

#### **5. Design Specifications**

##### **5.1 Layout**
- **Profile Picture Section:**
  - Circular placeholder with a camera icon for uploading photos.
  - Below the placeholder, text indicating allowed file types.
- **Personal Information Form:**
  - Labelled input fields for Name, Email Address, Address, Country, City, and Postal Code.
  - Right-aligned "Save Changes" button with a green background and white text.
  - Camera icon (`📷`) for profile picture upload.

##### **5.3 Interactions**
- **Hover States:**
  - "Save Changes" button: Light background color change on hover.
  - Input fields: Slight border color change on focus.
- **Active States:**
  - Clicked buttons: Pressed state with reduced opacity or shadow effect.
- **Validation Feedback:**
  - Error messages: Inline red text below invalid fields.
  - Success message: Toast notification or modal popup upon successful save.

##### **5.4 Animations**
- Smooth transitions for form validation feedback (e.g., error messages appearing/disappearing).
- Loading indicators for profile picture uploads.

##### **5.5 Accessibility**
- Ensure high contrast ratios for text and backgrounds.
- Use descriptive alt text for icons and images.
- Keyboard navigation support for all interactive elements.

---

#### **6. Key Features**
1. **Profile Picture Upload:**
   - Supports multiple image formats.
   - Displays a loading indicator during upload.
2. **Personal Information Form:**
   - Clear labels and input validations.
   - Read-only fields for immutable data (e.g., email).
3. **Responsive Design:**
   - Adapts seamlessly to desktop and mobile screens.
4. **Validation and Feedback:**
   - Real-time validation with clear error messages.
   - Confirmation notifications for successful saves.

---

#### **7. Conclusion**
The Account Settings - General Information page is designed to provide users with a seamless and intuitive experience for managing their personal details. By leveraging modern web technologies and adhering to best practices in UI/UX design, this feature ensures that users can easily update their information while maintaining data integrity and security. This PRD outlines the necessary functional and design requirements to build and maintain an effective account settings page.